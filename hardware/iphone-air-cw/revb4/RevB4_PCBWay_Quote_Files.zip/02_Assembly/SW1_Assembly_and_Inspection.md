# Rev B4 mechanical power switch

Populate **SW1, Nidec CAS-120TA**, on the top face using the B4 CPL, assembly view and manufacturer pin-1 indication. Confirm footprint orientation and actuator access. Keep solder, adhesive, cleaning fluids and the enclosure away from the moving actuator according to the switch manufacturer's handling instructions. Review the supplier's reflow restrictions when planning the two-sided assembly and the fixtured J1 operation. [Nidec CAS assembly and mechanical drawing](https://www.nidec-components.com/e/catalog/switch/cas.pdf)

| Terminal | Board net | What the contact controls |
|---|---|---|
| 1 | Isolated throw | Closure to terminal 2 selects OFF. R93 pulls the regulator enable low. |
| 2 | BOARD_EN | Common connected to U6 pin 5 and R93. |
| 3 | VBUS | Closure to terminal 2 selects ON and enables the main regulator. |

1. Remove USB, debugger power and other sources. After rails discharge, measure which pair of terminals shows a closed contact in each stable position. Record whether the A or B physical position closes 2 to 3 and which closes 2 to 1. Record the unit or lot ID. Protection paths and resistors may produce a finite reading on other contacts.
2. Apply a permanent ON mark beside the measured ON detent. Leave the slide and the test points clear. Support the board locally when operating the slide.
3. During supervised first power, measure TP7 (VBUS), TP6 (main 3V3), TP20 (MCU core) and TP8 (RF). OFF should discharge the main and core rails. The RF rail starts muted on a clean bench image after switching back to ON. TP7 may retain USB power throughout. Observe actual USB detach and enumeration after a complete power cycle.
4. Record both detent states, the continuity mapping, powered results and who inspected them. Return the board to OFF before packing.
